package introduction;

class Runn implements Runnable
{
    @Override
    public void run() {
        System.out.println("hi");
    }
}
public class CaseThread {
    public static void main(String[] args) {
        Runn runn = new Runn();
        Thread t1 = new Thread();
        Thread t2 = new Thread(runn);

        //t1.start(); Thread class start method executed by a new thread
        //t1.run(); Thread class run method executed like a method call, no new thread created
        //t2.start(); Runn class run() will be executed by a new thread
        //t2.run(); Runn class run() will be executed like a method call, no new thread
        //runn.start(); Error, no start() in runnable interface
        //runn.run(); Runn class run() will be executed like a normal method call

    }
}
