package introduction;

class InterruptThread extends Thread{
    @Override
    public void run() {
        for(int i=0;i<10000;i++)
        {
            System.out.println("Child thread i " + i);
        }
        System.out.println("I will sleep now");
        try{
            Thread.sleep(10000);
        } catch (Exception e)
        {
            System.out.println("Got interrupted");
        }
    }
}
public class InterruptThreadDemo {
    public static void main(String[] args) {
        InterruptThread interruptThread = new InterruptThread();
        interruptThread.start();
        interruptThread.interrupt();
        System.out.println("Main thread");
    }
}
