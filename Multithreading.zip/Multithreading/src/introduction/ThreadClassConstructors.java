package introduction;

public class ThreadClassConstructors {

    public static void main(String[] args) {

        Thread t1 = new Thread();
        Thread t2 = new Thread(new Runn());
        Thread t3 = new Thread(new Runn(), "String name");
        //Thread t4 = new Thread(ThreadGroup g, "String name");
        //Thread t5 = new Thread(ThreadGroup g, new Runn());
        //Thread t6 = new Thread(ThreadGroup g, new Runn(), "String name");
        //Thread t7 = new Thread(ThreadGroup g, new Runn(), "String name", long stacksize);

    }
}
