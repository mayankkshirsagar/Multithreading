package introduction;

class Display
{
    //public void wish(String name) we will get irregular output
    public synchronized void wish(String name)
    {
        for(int i=0;i<10;i++)
        {
            System.out.print("Good morning : ");
            try{
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {

            }
            System.out.println(name);
        }
    }
}
class DisplayThread extends Thread
{
    Display d;
    String name;
    DisplayThread(Display d, String name)
    {
        this.d = d;
        this.name = name;
    }

    @Override
    public void run() {
        d.wish(name);
    }
}
public class SynchronizeDemo {
    public static void main(String[] args) {
        Display d = new Display();
        DisplayThread d1 = new DisplayThread(d, "May");
        DisplayThread d2 = new DisplayThread(d, "Anj");
        d1.start();
        d2.start();
    }
}
