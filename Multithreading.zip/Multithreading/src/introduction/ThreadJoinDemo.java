package introduction;

class ThreadJoin extends Thread{
    @Override
    public void run() {
        for(int i=0;i<10;i++)
        {
            try {
                System.out.println("Child thread");
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {

            }
        }
    }
}
public class ThreadJoinDemo {
    public static void main(String[] args) throws Exception {
        ThreadJoin threadJoin = new ThreadJoin();
        threadJoin.start();
        threadJoin.join(); // line 1
        for(int i=0;i<10;i++)
        {
            System.out.println("Main thread");
        }
    }
}
