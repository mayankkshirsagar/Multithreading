package introduction;

class MyThreadEmpty extends Thread
{

}
public class EmptyRun {

    public static void main(String[] args) {
        MyThreadEmpty myThreadEmpty = new MyThreadEmpty();
        myThreadEmpty.start();
    }
}
