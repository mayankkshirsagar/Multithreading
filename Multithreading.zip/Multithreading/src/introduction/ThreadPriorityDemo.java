package introduction;

class ThreadPriority extends Thread
{

}
public class ThreadPriorityDemo {
    public static void main(String[] args) {
        System.out.println(Thread.currentThread().getPriority());
        //Thread.currentThread().setPriority(19);
        Thread.currentThread().setPriority(7);
        ThreadPriority tp = new ThreadPriority();
        System.out.println(tp.getPriority());
    }
}
