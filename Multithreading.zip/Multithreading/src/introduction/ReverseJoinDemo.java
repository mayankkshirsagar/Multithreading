package introduction;

class ReverseJoin extends Thread{
    static Thread myThread;
    @Override
    public void run() {
        try{
            myThread.join();
        } catch (InterruptedException e)
        {

        }
        for(int i =0;i<10;i++)
        {
            System.out.println("Child thread");
        }
    }
}
public class ReverseJoinDemo {
    public static void main(String[] args) throws Exception {
        ReverseJoin.myThread = Thread.currentThread();
        ReverseJoin reverseJoin = new ReverseJoin();
        reverseJoin.start();
        //reverseJoin.join(); //--line 1
        for(int i=0;i<10;i++) {
            System.out.println("Main thread");
            Thread.sleep(2000);
        }
    }
}
