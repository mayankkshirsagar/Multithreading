package introduction;

public class ThreadName {
    public static void main(String[] args) {
        System.out.println(Thread.currentThread().getName());
        Thread t1 = new Thread();
        System.out.println(t1.getName()); //Default name given Thread-0
        Thread.currentThread().setName("Mayank");
        System.out.println(Thread.currentThread().getName());
        System.out.println(10/0); //check the thread name in the error
    }
}
