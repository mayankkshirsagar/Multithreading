package introduction;

public class MyThread extends Thread {

    public void run() //overriding run method
    {
        for(int i=0;i<10;i++)
        {
            System.out.println("Child thread");
        }
    }

    public void run(int il) //overriding run method and Overloaded run method
    {
        for(int i=0;i<10;i++)
        {
            System.out.println("int run Child thread");
        }
    }
}
