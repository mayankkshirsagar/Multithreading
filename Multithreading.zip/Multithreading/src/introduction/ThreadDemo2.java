package introduction;

public class ThreadDemo2 {

    public static void main(String[] args) {
        MyThread myThread = new MyThread();
        myThread.start();
    }
}
