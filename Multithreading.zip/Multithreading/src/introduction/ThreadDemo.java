package introduction;

public class ThreadDemo {

    public static void main(String args[])
    {
        MyThread myThread = new MyThread(); //Thread initialization
        myThread.start(); //starting the thread
        // myThread.run();  this will not create a thread
        for(int i=0;i<10;i++)
        {
            System.out.println("Main thread");
        }
        //myThread.start(); Illegal thread state exception
    }
}
