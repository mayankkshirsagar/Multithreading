package introduction;


class RunThread implements Runnable //Defining a thread
{
    //executed by child thread
    public void run() //job of thread
    {
        for(int i=0;i<5;i++)
        {
            System.out.println("Child thread");
        }
    }
}

public class RunnableThread {
    public static void main(String[] args) {
        RunThread runThread = new RunThread();
        Thread thread = new Thread(runThread); //target runnable
        thread.start();

        //executed by main thread
        for(int i=0;i<5;i++){
            System.out.println("Main thread");
        }
    }
}
