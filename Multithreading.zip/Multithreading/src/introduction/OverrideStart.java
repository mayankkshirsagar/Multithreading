package introduction;

class MyThreadStart extends Thread
{
    public void start()
    {
        //super.start(); // this will call the parent start and will execute as a thread
        //possible output with this
        //start -> Main -> run
        //start -> run -> main
        //run -> Start -> Main
        // child thread will execute Run
        // Main thread will execute Start -> Main
        System.out.println("start method");
    }

    public void run()
    {
        System.out.println("run method");
    }
}
public class OverrideStart {

    public static void main(String[] args) {
        MyThreadStart myThreadStart = new MyThreadStart();
        myThreadStart.start();
        System.out.println("Main method");
    }
}
