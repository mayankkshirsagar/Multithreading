package introduction;

public class SameThreadJoin {
    public static void main(String[] args) throws InterruptedException {
        Thread.currentThread().join();
    }
}
