package introduction;

class ThreadNameDemo2 extends Thread{
    @Override
    public void run() {
        System.out.println("Run method executed by : " + Thread.currentThread().getName());
    }
}
public class ThreadName2 {
    public static void main(String[] args) {
        ThreadNameDemo2 demo2 = new ThreadNameDemo2();
        demo2.start();
        System.out.println("Main method executed by : " + Thread.currentThread().getName());
    }
}
