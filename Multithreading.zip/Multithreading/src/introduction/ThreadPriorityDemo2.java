package introduction;

class ThreadPriority2 extends Thread{
    @Override
    public void run() {
        for(int i=0;i<5;i++)
            System.out.println("child thread");
    }
}
public class ThreadPriorityDemo2 {
    public static void main(String[] args) {
        ThreadPriority2 threadPriority2 = new ThreadPriority2();
        //threadPriority2.setPriority(10); Line 1
        threadPriority2.start();
        for(int i=0;i<5;i++)
            System.out.println("Main thread");
    }
}
