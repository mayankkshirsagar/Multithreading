package introduction;

class HybridThread extends Thread{

    @Override
    public void run() {
        System.out.println("Child thread");
    }
}
public class Hybrid {
    public static void main(String[] args) {
        HybridThread hybridThread = new HybridThread();
        Thread t1 = new Thread(hybridThread);
        t1.start();
        System.out.println("Main thread");
    }
}

// op main thread -> child thread
// op child thread -> main thread